https://github.com/jamesatighe/AVD-BICEP

https://tighetec.co.uk/2021/07/07/deploy-azure-virtual-desktop-with-project-bicep/

https://alven.tech/windows-virtual-desktop-with-arm-and-azure-devops/

https://www.golinuxcloud.com/azure-logic-apps-tutorial/
