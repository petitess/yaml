## A template to deploy Azure Monitor Agent

[Manage the Azure Monitor agent](https://learn.microsoft.com/en-us/azure/azure-monitor/agents/azure-monitor-agent-manage)

Prerequisites:

Log Analytics Workspace

Managed identity must be enabled on Azure virtual machines.

Data collection rule and association



