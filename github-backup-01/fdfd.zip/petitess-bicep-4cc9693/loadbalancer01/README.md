## Internal Load Balancer
<img src="./LB.png"/>