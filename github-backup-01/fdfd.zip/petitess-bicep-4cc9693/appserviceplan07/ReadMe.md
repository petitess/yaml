1. Install a certificate: Key Vault > certificates > PFX
2. Create TXT and A record
3. Deploy

#### https://learn.microsoft.com/en-us/azure/app-service/configure-ssl-certificate?tabs=apex#create-a-free-managed-certificate
