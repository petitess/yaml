| Connector | Connector API name |
|-|-|
Azure Container Instance | aci 
Azure Resource Manager | arm 
Azure Automation | azureautomation 
Azure Data Factory | azuredatafactory 
Azure Data Lake | azuredatalake 
Azure Key Vault | keyvault 
Azure Event Grid | azureeventgrid 
Azure Sentinel | azuresentinel 
Azure Data Explorer (Preview) | kusto 
Azure AD Identity Protection (Preview) | azureadip 
Azure IoT Central V3 (Preview) | azureiotcentral 
HTTP with Azure AD | webcontents
