[Direct web traffic with Azure Application Gateway](https://docs.microsoft.com/en-us/azure/application-gateway/quick-create-bicep?tabs=CLI)

[Choosing a load balancing option for Azure](https://docs.microsoft.com/en-gb/learn/modules/load-balancing-non-https-traffic-azure/2-explore)
<img src="./AGW.png"/>
