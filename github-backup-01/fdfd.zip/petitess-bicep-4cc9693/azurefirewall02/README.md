### Application Gateway with private basic listener. Routed through Azure Firewall.

<img src="./AFW-AGW.png"/>



