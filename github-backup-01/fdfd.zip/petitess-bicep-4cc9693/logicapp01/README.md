# Logic app - Consumption

## AD user password expiration notification

### This logic app checks if AD user passoword expires and sends an email to users.

Deploy bicep template

Authorize office365 connection

In AdPasswordExpiration.ps1 put storage account name.

Put AdPasswordExpiration.ps1 on a management server under C:/B3

<img src="./1.png"/>
