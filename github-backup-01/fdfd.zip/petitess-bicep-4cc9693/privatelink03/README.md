Use Azure Storage Explorer on vm01 to access st01 privately
<img src="./PE.png" alt="PE"/>