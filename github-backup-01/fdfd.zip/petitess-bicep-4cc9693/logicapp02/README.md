# Logic app - Consumption

## Azure Resource Graph Query

### This logic app sends an email with windows update summary.

This logic app needs to be reader in the subscription

Authorize office365 connection manually

<img src="./1.png"/>
