## A template to deploy Azure Update Manager

[How to enable Azure Update Manager](https://learn.microsoft.com/en-us/azure/update-center/enable-machines?tabs=portal-periodic)





