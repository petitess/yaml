### Azure Virtual Desktop - Host Pool, App Groups, Workspace.

Registry settings for virtual machine using run command.

To be able to use storage account for FSLogix, deploy Microsoft Entra Domain Services.

[Deploy Azure Virtual Desktop](https://learn.microsoft.com/en-us/azure/virtual-desktop/deploy-azure-virtual-desktop?tabs=portal)
