Application Rule doesn't work for some reason
<img src="./AFW.png"/>